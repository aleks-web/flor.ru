import{dx as e,cO as d,dy as f,dz as h}from"./main-PxdaHJps.js";var o=e?e.isConcatSpreadable:void 0;function m(n){return d(n)||f(n)||!!(o&&n&&n[o])}function p(n,g,i,r,a){var t=-1,b=n.length;for(i||(i=m),a||(a=[]);++t<b;){var s=n[t];i(s)?h(a,s):r||(a[a.length]=s)}return a}export{p as b};
//# sourceMappingURL=_baseFlatten-BJ1WAQsn.js.map
