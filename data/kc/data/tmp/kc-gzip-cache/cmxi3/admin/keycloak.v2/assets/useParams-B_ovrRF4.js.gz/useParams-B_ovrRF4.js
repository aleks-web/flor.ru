import{c as s}from"./main-PxdaHJps.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-B_ovrRF4.js.map
