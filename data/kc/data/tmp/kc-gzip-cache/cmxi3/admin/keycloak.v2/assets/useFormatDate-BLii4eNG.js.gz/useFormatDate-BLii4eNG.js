import{cY as r}from"./main-PxdaHJps.js";const s={dateStyle:"long",timeStyle:"short"};function c(){const{whoAmI:t}=r();return function(o,e){return o.toLocaleString(t.locale,e)}}export{s as F,c as u};
//# sourceMappingURL=useFormatDate-BLii4eNG.js.map
