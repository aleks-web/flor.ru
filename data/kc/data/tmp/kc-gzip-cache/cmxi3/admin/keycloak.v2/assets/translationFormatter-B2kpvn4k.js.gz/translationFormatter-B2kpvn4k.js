import{cg as o}from"./main-PxdaHJps.js";const e=t=>r=>r&&o(t,r)||"—";export{e as t};
//# sourceMappingURL=translationFormatter-B2kpvn4k.js.map
